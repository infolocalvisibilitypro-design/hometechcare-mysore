HomeTechCare FINAL Website
==========================
Vercel-ready static website.

Phone/WhatsApp: +91 82961 46761
Primary local SEO: Home Appliance Repair in Mysore

The visible site uses image URLs from third-party service websites as visual references.
Before commercial launch, replace these image URLs with images you own or have explicit permission/licensing to use.

The booking forms open WhatsApp with the customer's submitted details.
